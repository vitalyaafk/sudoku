import random

def valid(board, row, col, number):
    if number in board[row]:
        return False
    if any(board[r][col] == number for r in range(9)):
        return False
    box_row, box_col = (row // 3) * 3, (col // 3) * 3
    for r in range(box_row, box_row + 3):
        for c in range(box_col, box_col + 3):
            if board[r][c] == number:
                return False
    return True


def fill_board(board):
    for row in range(9):
        for col in range(9):
            if board[row][col] == 0:
                numbers = list(range(1, 10))
                random.shuffle(numbers)
                for number in numbers:
                    if valid(board, row, col, number):
                        board[row][col] = number
                        if fill_board(board):
                            return True
                        board[row][col] = 0
                return False
    return True


def count_solutions(board, limit=2):
    """Count solutions, stopping at limit; used to preserve a unique puzzle."""
    for row in range(9):
        for col in range(9):
            if board[row][col] == 0:
                total = 0
                for number in range(1, 10):
                    if valid(board, row, col, number):
                        board[row][col] = number
                        total += count_solutions(board, limit - total)
                        board[row][col] = 0
                        if total >= limit:
                            return total
                return total
    return 1


def make_puzzle(difficulty):
    clues = {"easy": (39, 43), "medium": (32, 36), "hard": (27, 30)}
    solution = [[0] * 9 for _ in range(9)]
    fill_board(solution)
    puzzle = [row[:] for row in solution]
    target = random.randint(*clues[difficulty])
    cells = [(r, c) for r in range(9) for c in range(9)]
    random.shuffle(cells)

    for row, col in cells:
        if sum(value != 0 for line in puzzle for value in line) <= target:
            break
        previous = puzzle[row][col]
        puzzle[row][col] = 0
        test = [line[:] for line in puzzle]
        if count_solutions(test) != 1:
            puzzle[row][col] = previous

    return puzzle, solution
