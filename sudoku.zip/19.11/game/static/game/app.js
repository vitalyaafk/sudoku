const boardEl = document.getElementById("board");
const timerEl = document.getElementById("timer");
const mistakesEl = document.getElementById("mistakes");
const statusEl = document.getElementById("status");
let puzzle = [], values = [], selected = null, gameId = null;
let mistakes = 0, seconds = 0, notesMode = false, noteMap = {}, timerInterval = null;
let checking = false, finished = false;

function csrfToken() {
  const match = document.cookie.match(/(?:^|; )csrftoken=([^;]*)/);
  return match ? decodeURIComponent(match[1]) : window.SUDOKU_CSRF;
}
async function api(url, data) {
  const response = await fetch(url, {
    method: "POST",
    headers: {"Content-Type":"application/json", "X-CSRFToken":csrfToken()},
    body: JSON.stringify(data)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Сталася помилка.");
  return result;
}
function setStatus(message, type="") {
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
}
function formatTime(value) {
  return `${String(Math.floor(value/60)).padStart(2,"0")}:${String(value%60).padStart(2,"0")}`;
}
async function startGame() {
  clearInterval(timerInterval);
  finished = false; checking = false; selected = null; mistakes = 0; seconds = 0; noteMap = {};
  mistakesEl.textContent = "0"; timerEl.textContent = "00:00";
  setStatus("Генеруємо нову головоломку…");
  document.getElementById("newGameBtn").disabled = true;
  try {
    const data = await api("/api/new-game/", {difficulty:document.getElementById("difficulty").value});
    gameId = data.game_id;
    puzzle = data.puzzle;
    values = puzzle.map(row => [...row]);
    document.getElementById("gameLabel").textContent = `НОВА ГРА · ${data.clues} ЦИФР`;
    render();
    setStatus(`Новий рівень готовий! Початкових цифр: ${data.clues}.`);
    timerInterval = setInterval(() => { seconds++; timerEl.textContent = formatTime(seconds); }, 1000);
  } catch (error) {
    setStatus(error.message, "error");
  } finally {
    document.getElementById("newGameBtn").disabled = false;
  }
}
function related(r,c,rr,cc) {
  return r===rr || c===cc || (Math.floor(r/3)===Math.floor(rr/3) && Math.floor(c/3)===Math.floor(cc/3));
}
function render() {
  boardEl.innerHTML = "";
  for (let r=0;r<9;r++) for (let c=0;c<9;c++) {
    const cell = document.createElement("button");
    cell.type = "button"; cell.className = "cell"; cell.setAttribute("role","gridcell");
    cell.setAttribute("aria-label",`Рядок ${r+1}, стовпець ${c+1}, ${values[r][c] || "порожньо"}`);
    if (puzzle[r][c]) cell.classList.add("fixed");
    if (selected && selected[0]===r && selected[1]===c) cell.classList.add("selected");
    if (selected && related(r,c,selected[0],selected[1])) cell.classList.add("related");
    if (selected && values[r][c] && values[r][c]===values[selected[0]][selected[1]]) cell.classList.add("same");
    if (values[r][c]) cell.textContent = values[r][c];
    else if (noteMap[`${r}-${c}`]?.length) {
      const notes = document.createElement("span"); notes.className = "notes";
      notes.textContent = noteMap[`${r}-${c}`].sort().join(" "); cell.appendChild(notes);
    }
    cell.addEventListener("click",()=>{ selected=[r,c]; render(); });
    boardEl.appendChild(cell);
  }
}
async function enterNumber(number) {
  if (!selected || finished || checking) return;
  const [r,c] = selected;
  if (puzzle[r][c]) return;
  if (number === "erase") {
    values[r][c]=0; delete noteMap[`${r}-${c}`]; render(); return;
  }
  if (notesMode) {
    const key = `${r}-${c}`, notes = noteMap[key] || [];
    noteMap[key] = notes.includes(number) ? notes.filter(n=>n!==number) : [...notes,number];
    render(); return;
  }
  checking = true;
  try {
    const result = await api("/api/check-cell/", {game_id:gameId,row:r,col:c,value:number});
    if (!result.correct) {
      mistakes++; mistakesEl.textContent = String(mistakes);
      boardEl.children[r*9+c].classList.add("conflict");
      setStatus(`Цифра не підходить. Помилок: ${mistakes}.`, "error");
      if (mistakes >= 3) {
        clearInterval(timerInterval); finished = true;
        setStatus("Три помилки. Можеш почати нову гру.", "error");
      }
    } else {
      values[r][c] = number; delete noteMap[`${r}-${c}`]; render();
      setStatus("Правильно! Продовжуй.");
      if (values.every(row=>row.every(value=>value!==0))) await completeGame();
    }
  } catch (error) { setStatus(error.message,"error"); }
  finally { checking = false; }
}
async function completeGame() {
  try {
    const result = await api("/api/finish-game/", {
      game_id:gameId, board:values, elapsed_seconds:seconds, mistakes
    });
    finished = true; clearInterval(timerInterval);
    setStatus(`Вітаємо! Судоку розв’язано за ${formatTime(seconds)}.${result.saved ? " Результат збережено!" : " Увійди або зареєструйся, щоб зберігати результати."}`, "success");
    loadLeaderboard();
  } catch (error) { setStatus(error.message,"error"); }
}
document.querySelectorAll("[data-number]").forEach(button => {
  button.addEventListener("click",()=>enterNumber(button.dataset.number==="erase"?"erase":Number(button.dataset.number)));
});
document.addEventListener("keydown",event=>{
  if (/^[1-9]$/.test(event.key)) enterNumber(Number(event.key));
  if (event.key==="Backspace" || event.key==="Delete") enterNumber("erase");
});
document.getElementById("newGameBtn").addEventListener("click",startGame);
document.getElementById("difficulty").addEventListener("change",startGame);
document.getElementById("checkBtn").addEventListener("click",()=>{
  if (!selected) return setStatus("Спочатку обери клітинку.");
  const [r,c]=selected;
  if (puzzle[r][c]) return setStatus("Це початкова цифра.");
  if (!values[r][c]) return setStatus("Клітинка порожня.");
  setStatus("Перевірка відбувається автоматично після введення цифри.");
});
document.getElementById("notesBtn").addEventListener("click",()=>{
  notesMode=!notesMode;
  document.querySelector("#notesBtn span").textContent=notesMode?"Увімк.":"Вимк.";
  document.getElementById("notesBtn").classList.toggle("active",notesMode);
  setStatus(notesMode?"Режим нотаток увімкнено. Обирай цифри для нотаток.":"Режим нотаток вимкнено.");
});
async function loadLeaderboard() {
  const list = document.getElementById("leaderboard");
  try {
    const response = await fetch("/api/leaderboard/");
    const data = await response.json();
    list.innerHTML = "";
    if (!data.results.length) { list.innerHTML = "<li>Поки немає результатів</li>"; return; }
    data.results.forEach((entry,index)=>{
      const li=document.createElement("li");
      const name=document.createElement("span"); name.textContent=`${index+1}. ${entry.user__username}`;
      const time=document.createElement("strong"); time.textContent=formatTime(entry.best_time);
      li.append(name,time); list.appendChild(li);
    });
  } catch { list.innerHTML="<li>Не вдалося завантажити</li>"; }
}
startGame();
loadLeaderboard();
