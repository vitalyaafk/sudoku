from django.conf import settings
from django.db import models

class SudokuGame(models.Model):
    DIFFICULTIES = [
        ("easy", "Легка"),
        ("medium", "Середня"),
        ("hard", "Складна"),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True, related_name="sudoku_games")
    difficulty = models.CharField(max_length=10, choices=DIFFICULTIES)
    puzzle = models.JSONField()
    solution = models.JSONField()
    completed = models.BooleanField(default=False)
    elapsed_seconds = models.PositiveIntegerField(default=0)
    mistakes = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Sudoku #{self.pk} ({self.get_difficulty_display()})"


class GameResult(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="sudoku_results")
    game = models.OneToOneField(SudokuGame, on_delete=models.CASCADE, related_name="result")
    difficulty = models.CharField(max_length=10, choices=SudokuGame.DIFFICULTIES)
    elapsed_seconds = models.PositiveIntegerField()
    mistakes = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["elapsed_seconds", "created_at"]

    def __str__(self):
        return f"{self.user.username}: {self.get_difficulty_display()} — {self.elapsed_seconds}s"
