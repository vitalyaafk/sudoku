import json
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Min
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST, require_GET
from .models import SudokuGame, GameResult
from .sudoku import make_puzzle


def home(request):
    return render(request, "game/index.html")


def _json_body(request):
    try:
        return json.loads(request.body.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None


@require_POST
def new_game(request):
    data = _json_body(request)
    if not isinstance(data, dict):
        return JsonResponse({"error": "Некоректний запит."}, status=400)
    difficulty = data.get("difficulty", "easy")
    if difficulty not in ("easy", "medium", "hard"):
        return JsonResponse({"error": "Невідомий рівень складності."}, status=400)

    puzzle, solution = make_puzzle(difficulty)
    game = SudokuGame.objects.create(
        user=request.user if request.user.is_authenticated else None,
        difficulty=difficulty,
        puzzle=puzzle,
        solution=solution,
    )
    return JsonResponse({
        "game_id": game.id,
        "puzzle": puzzle,
        "difficulty": difficulty,
        "clues": sum(v != 0 for row in puzzle for v in row),
    })


@require_POST
def check_cell(request):
    data = _json_body(request)
    if not isinstance(data, dict):
        return JsonResponse({"error": "Некоректний запит."}, status=400)
    try:
        game = SudokuGame.objects.get(pk=int(data.get("game_id")))
        row, col, value = int(data.get("row")), int(data.get("col")), int(data.get("value"))
    except (TypeError, ValueError, SudokuGame.DoesNotExist):
        return JsonResponse({"error": "Не вдалося знайти гру або клітинку."}, status=400)
    if not (0 <= row < 9 and 0 <= col < 9 and 1 <= value <= 9):
        return JsonResponse({"error": "Некоректні координати або цифра."}, status=400)
    if game.user_id and (not request.user.is_authenticated or game.user_id != request.user.id):
        return JsonResponse({"error": "Ця гра належить іншому користувачу."}, status=403)
    if game.puzzle[row][col] != 0:
        return JsonResponse({"error": "Це початкова клітинка."}, status=400)
    return JsonResponse({"correct": game.solution[row][col] == value})


@require_POST
def finish_game(request):
    data = _json_body(request)
    if not isinstance(data, dict):
        return JsonResponse({"error": "Некоректний запит."}, status=400)
    try:
        game = SudokuGame.objects.get(pk=int(data.get("game_id")))
        board = data.get("board")
        elapsed = max(0, min(int(data.get("elapsed_seconds", 0)), 86400))
        mistakes = max(0, min(int(data.get("mistakes", 0)), 99))
    except (TypeError, ValueError, SudokuGame.DoesNotExist):
        return JsonResponse({"error": "Не вдалося завершити гру."}, status=400)
    if game.user_id and (not request.user.is_authenticated or game.user_id != request.user.id):
        return JsonResponse({"error": "Ця гра належить іншому користувачу."}, status=403)
    if not isinstance(board, list) or len(board) != 9 or any(not isinstance(row, list) or len(row) != 9 for row in board):
        return JsonResponse({"error": "Поле має містити 9 рядків по 9 клітинок."}, status=400)
    try:
        normalized = [[int(v) for v in row] for row in board]
    except (TypeError, ValueError):
        return JsonResponse({"error": "У полі є некоректні значення."}, status=400)
    if any(v < 1 or v > 9 for row in normalized for v in row):
        return JsonResponse({"error": "Заповни всі клітинки цифрами від 1 до 9."}, status=400)
    # Do not trust the browser: compare the submitted board with the server-side solution.
    if normalized != game.solution:
        return JsonResponse({"error": "Поле ще не заповнене правильно."}, status=400)

    if not game.completed:
        game.completed = True
        game.elapsed_seconds = elapsed
        game.mistakes = mistakes
        game.save(update_fields=["completed", "elapsed_seconds", "mistakes"])
        if request.user.is_authenticated:
            GameResult.objects.create(
                user=request.user, game=game, difficulty=game.difficulty,
                elapsed_seconds=elapsed, mistakes=mistakes,
            )
    return JsonResponse({"success": True, "saved": request.user.is_authenticated})


@require_GET
def leaderboard(request):
    rows = (GameResult.objects.values("user__username")
            .annotate(games=Count("id"), best_time=Min("elapsed_seconds"))
            .order_by("best_time")[:10])
    return JsonResponse({"results": list(rows)})


def register(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = UserCreationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Акаунт створено. Успішної гри!")
        return redirect("home")
    return render(request, "game/auth.html", {"form": form, "mode": "register"})


def login_view(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = AuthenticationForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.get_user())
        return redirect("home")
    return render(request, "game/auth.html", {"form": form, "mode": "login"})


def logout_view(request):
    if request.method == "POST":
        logout(request)
    return redirect("home")
