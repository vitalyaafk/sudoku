from django.contrib import admin
from .models import SudokuGame, GameResult

@admin.register(SudokuGame)
class SudokuGameAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "difficulty", "completed", "created_at")
    list_filter = ("difficulty", "completed")

@admin.register(GameResult)
class GameResultAdmin(admin.ModelAdmin):
    list_display = ("user", "difficulty", "elapsed_seconds", "mistakes", "created_at")
    list_filter = ("difficulty",)
