from django.contrib import admin
from django.urls import path
from game import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.home, name="home"),
    path("api/new-game/", views.new_game, name="new_game"),
    path("api/check-cell/", views.check_cell, name="check_cell"),
    path("api/finish-game/", views.finish_game, name="finish_game"),
    path("api/leaderboard/", views.leaderboard, name="leaderboard"),
    path("register/", views.register, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
]
